# little loop. — Crochet storefront

A single-file, responsive storefront designed for free static hosting with GitHub Pages.

## Publish on GitHub Pages
1. Sign in to GitHub and create a new **public** repository, for example `little-loop-store`.
2. Upload `index.html` and `README.md` from this folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for the published link shown in Settings → Pages.

## Before launch — edit `index.html`
Search in the file for these settings:
- `WHATSAPP_NUMBER = "919876543210"` — replace with your WhatsApp number including country code, with no plus sign/spaces.
- `INSTAGRAM_URL` — replace with your Instagram profile.
- `const products = [` — change product names, prices, descriptions, categories and emojis.
- For real product photography, replace each emoji inside `.product-art` with an `<img>` element and set `object-fit: cover`; upload the images to the repository and use relative paths like `images/tulip.jpg`.
- Change `little loop` / `little loop studio` to your brand name.

## What works
- Responsive landing page and product grid
- Category filters
- Add-to-cart, quantity controls and subtotal
- WhatsApp order message

## Important limitations
This is a front-end demo, not a full ecommerce backend. It does not process online payments, manage stock, send email newsletters, or calculate shipping/taxes. Orders are confirmed manually over WhatsApp. GitHub Pages is static hosting; do not put passwords, API secrets, or private customer data in the code.
